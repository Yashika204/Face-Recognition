# Parth639---Yashika204-Face-Recognition
![image](https://user-images.githubusercontent.com/110775475/221423340-502df089-ced3-4c17-8972-9a9693d78020.png)
[Student Details - Google Chrome 2023-02-26 21-58-51.zip](https://github.com/Parth639/Parth639---Yashika204-Face-Recognition/files/10834166/Student.Details.-.Google.Chrome.2023-02-26.21-58-51.zip)
![image](https://user-images.githubusercontent.com/110775475/221423521-0d460de1-0776-4efa-a103-3eb354a6101a.png)
![face_detector model](https://user-images.githubusercontent.com/110775475/221424040-c4cef90e-217d-46e9-ab49-dae37703c854.jpg)
